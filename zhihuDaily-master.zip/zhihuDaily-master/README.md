#知乎日报(高仿)
----------
#####所使用的数据均出自知乎服务器，其中API参考[@izzyleung](https://github.com/izzyleung/ZhihuDailyPurify/wiki/%E7%9F%A5%E4%B9%8E%E6%97%A5%E6%8A%A5-API-%E5%88%86%E6%9E%90)，表示感谢，另外经分析，知乎的一些API返回的数据有的不规则，需要另作完善。
-----------

>演示视频请移步[这里](http://v.youku.com/v_show/id_XMTQ4NTg2NjI2NA==.html)


![](https://github.com/beyanger/zhihuDaily/blob/master/zhihuDaily/Resources/1.gif)
![](https://github.com/beyanger/zhihuDaily/blob/master/zhihuDaily/Resources/2.gif)
![](https://github.com/beyanger/zhihuDaily/blob/master/zhihuDaily/Resources/3.gif)
![](https://github.com/beyanger/zhihuDaily/blob/master/zhihuDaily/Resources/4.gif)
![](https://github.com/beyanger/zhihuDaily/blob/master/zhihuDaily/Resources/5.gif)
![](https://github.com/beyanger/zhihuDaily/blob/master/zhihuDaily/Resources/6.gif)



#####主要界面高度还原知乎官方APP，除了和账号相关的操作尚未实现，其他基本功能均已经实现。包括动画效果，数据缓存，下拉自动刷新数据等。
-------------
##尚未完成：
1. ~~登录和~~分享功能，包括点赞，~~收藏~~等(界面已经实现动画效果) 采用本地数据库存储方式实现
2. ~~分享面板在6和6p上显示混乱(约束不完整)~~
3. ~~知乎API的查看新闻详情，有些返回的数据不规则需要另行处理~~
4. ~~加载更多评论~~
5.  ~~MMDrawerController有时候在深层次右滑的时候会都多级滑动(FIXME)~~
6.  夜间模式




-------------
E-mail： `beyanger@gmail.com`
[这里](http://blog.beyanger.com)
-------------
`求随手一个小`⭐️
