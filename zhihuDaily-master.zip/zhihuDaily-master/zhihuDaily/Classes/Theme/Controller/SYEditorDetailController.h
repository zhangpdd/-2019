//
//  SYEditorDetailController.h
//  zhihuDaily
//
//  Created by yang on 16/2/28.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYBaseViewController.h"
#import "SYEditor.h"
#import "SYRecommender.h"
@interface SYEditorDetailController : SYBaseViewController

@property (nonatomic, strong)  id editor;

@end
