//
//  SYCollectionController.h
//  zhihuDaily
//
//  Created by yang on 16/3/2.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYStoryListController.h"

@interface SYCollectionController : SYStoryListController

@end
