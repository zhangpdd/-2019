//
//  SYSettingController.h
//  zhihuDaily
//
//  Created by yang on 16/2/22.
//  Copyright © 2016年 yang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYBaseViewController.h"


@interface SYSettingController : SYBaseViewController

@end
