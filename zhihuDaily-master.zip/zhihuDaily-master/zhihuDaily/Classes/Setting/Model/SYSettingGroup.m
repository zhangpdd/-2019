//
//  SYSettingGroup.m
//  zhihuDaily
//
//  Created by yang on 16/2/27.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYSettingGroup.h"


@implementation SYSettingGroup

@end
