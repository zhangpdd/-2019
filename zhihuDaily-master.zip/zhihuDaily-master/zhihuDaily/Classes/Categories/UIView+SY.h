//
//  UIView+SY.h
//  zhihuDaily
//
//  Created by yang on 16/3/1.
//  Copyright © 2016年 yang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (SY)

- (UIImage *)snapshort;


@end
