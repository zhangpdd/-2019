//
//  SYCommentView.h
//  zhihuDaily
//
//  Created by yang on 16/2/29.
//  Copyright © 2016年 yang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYCommentView : UIView

+ (instancetype)commentView;

@end
