//
//  SYTableViewCell.h
//  zhihuDaily
//
//  Created by yang on 16/2/22.
//  Copyright © 2016年 yang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYStory.h"

@interface SYTableViewCell : UITableViewCell

@property (nonatomic, strong) SYStory *story;

@end
