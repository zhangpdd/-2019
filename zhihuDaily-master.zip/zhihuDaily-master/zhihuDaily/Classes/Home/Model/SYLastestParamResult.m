//
//  SYParamResult.m
//  zhihuDaily
//
//  Created by yang on 16/2/22.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYLastestParamResult.h"

@implementation SYLastestParamResult

@end
