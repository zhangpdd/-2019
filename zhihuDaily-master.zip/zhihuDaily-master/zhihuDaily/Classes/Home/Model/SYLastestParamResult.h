//
//  SYParamResult.h
//  zhihuDaily
//
//  Created by yang on 16/2/22.
//  Copyright © 2016年 yang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SYBeforeStoryResult.h"
@interface SYLastestParamResult : SYBeforeStoryResult

@property (nonatomic, strong) NSArray *top_stories;

@end
