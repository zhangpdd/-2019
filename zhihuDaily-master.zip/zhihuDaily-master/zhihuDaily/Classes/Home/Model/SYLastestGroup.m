//
//  SYLastestGroup.m
//  zhihuDaily
//
//  Created by yang on 16/2/22.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYLastestGroup.h"

@implementation SYLastestGroup

@end
