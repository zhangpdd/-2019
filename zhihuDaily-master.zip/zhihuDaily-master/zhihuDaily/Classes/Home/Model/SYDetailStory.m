//
//  SYDetailStory.m
//  zhihuDaily
//
//  Created by yang on 16/2/23.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYDetailStory.h"
#import "MJExtension.h"
@implementation SYDetailStory

MJCodingImplementation
@end
