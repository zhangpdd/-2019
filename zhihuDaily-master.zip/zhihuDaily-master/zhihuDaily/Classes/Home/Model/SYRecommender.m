//
//  SYRecommender.m
//  zhihuDaily
//
//  Created by yang on 16/2/28.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYRecommender.h"
#import "MJExtension.h"

@implementation SYRecommender

MJCodingImplementation

@end
