//
//  SYPresentAnimation.h
//  zhihuDaily
//
//  Created by yang on 16/2/23.
//  Copyright © 2016年 yang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SYPresentAnimation : NSObject <UIViewControllerAnimatedTransitioning>

@end
