//
//  SYCommentsTableController.h
//  zhihuDaily
//
//  Created by yang on 16/2/23.
//  Copyright © 2016年 yang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYStory.h"
#import "SYComment.h"
#import "SYBaseViewController.h"
#import "SYCommentParam.h"


@interface SYCommentsController : SYBaseViewController

@property (nonatomic, strong) SYCommentParam *param;

@end
