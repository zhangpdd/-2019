//
//  SYLoginController.h
//  zhihuDaily
//
//  Created by yang on 16/3/2.
//  Copyright © 2016年 yang. All rights reserved.
//

#import "SYBaseViewController.h"

@interface SYLoginController : SYBaseViewController

@end
